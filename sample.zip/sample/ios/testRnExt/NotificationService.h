//
//  NotificationService.h
//  testRnExt
//
//  Created by ldja on 2021/09/29.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
